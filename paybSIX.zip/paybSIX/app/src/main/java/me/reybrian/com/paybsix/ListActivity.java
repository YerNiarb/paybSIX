package me.reybrian.com.paybsix;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ListAdapter;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
    ListView lstView_utang;
    DBController dbController;
    Utang u;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        lstView_utang = (ListView) findViewById(R.id.listView_Utang);
        dbController = new DBController(this);

        populateList();
    }

    private void populateList(){
        Cursor data = dbController.getData();

        final ArrayList<Utang> lista = new ArrayList<>();
        while(data.moveToNext()){
            u = new Utang(data.getString(0), data.getString(1), data.getString(2));
            lista.add(u);
        }
        ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);
        lstView_utang.setAdapter(adapter);

        lstView_utang.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String _id = lista.get(position).getId();
                String name = lista.get(position).getName();
                String amount = lista.get(position).getAmt();

                Intent intentEditScreen = new Intent(ListActivity.this, EditDeleteActivity.class);
                intentEditScreen.putExtra("uId", _id);
                intentEditScreen.putExtra("uName", name);
                intentEditScreen.putExtra("uAmt", amount);
                startActivity(intentEditScreen);
            }
        });
    }
}
