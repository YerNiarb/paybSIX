package me.reybrian.com.paybsix;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditDeleteActivity extends AppCompatActivity {
    DBController dbController;
    EditText edt_uName, edt_uAmt;
    Button btn_del, btn_upd;
    String sName, sAmt, sId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_delete);
        final DBController dbController = new DBController(this);
        edt_uName = (EditText) findViewById(R.id.edtTxt_uName);
        edt_uAmt = (EditText) findViewById(R.id.edtTxt_uAmt);
        btn_del = (Button) findViewById(R.id.btn_delete);
        btn_upd = (Button) findViewById(R.id.btn_update);

        Intent receivedIntent = getIntent();
        sId = receivedIntent.getStringExtra("uId");
        sName = receivedIntent.getStringExtra("uName");
        sAmt = receivedIntent.getStringExtra("uAmt");

        final Utang editUtang = new Utang(sId, sName, sAmt);
        edt_uName.setText(editUtang.getName());
        edt_uAmt.setText(editUtang.getAmt());

        btn_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbController.delete(editUtang.getId());
                toastMessage("Utang deleted.");
                Intent intent = new Intent(EditDeleteActivity.this, ListActivity.class);
                startActivity(intent);
            }
        });

        btn_upd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbController.update(editUtang.getId(), edt_uName.getText().toString(), edt_uAmt.getText().toString());
                toastMessage("Utang updated");
                Intent intent = new Intent(EditDeleteActivity.this, ListActivity.class);
                startActivity(intent);
            }
        });
    }

public void toastMessage(String msg){
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
}
}
