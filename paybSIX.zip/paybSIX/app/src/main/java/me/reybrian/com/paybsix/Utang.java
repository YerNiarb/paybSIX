package me.reybrian.com.paybsix;

public class Utang {
    String name;
    String amt;
    String id;

    public Utang(String name, String amt) {
        this.name = name;
        this.amt = amt;
    }

    public Utang(String id, String name, String amt) {
        this.id = id;
        this.name = name;
        this.amt = amt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAmt() {
        return amt;
    }

    public void setAmt(String amt) {
        this.amt = amt;
    }

    @Override
    public String toString() {
        return "Utang{" +
                "name='" + name + '\'' +
                ", amt='" + amt + '\'' +
                '}';
    }
}
