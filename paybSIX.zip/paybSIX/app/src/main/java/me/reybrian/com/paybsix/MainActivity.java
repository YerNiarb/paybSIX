package me.reybrian.com.paybsix;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn_Save;
    Button btn_View;
    EditText edt_Nm;
    EditText edt_Amt;
    DBController dbController;
    Utang utang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_Save = (Button) findViewById(R.id.btn_save);
        btn_View = (Button) findViewById(R.id.btn_view);
        edt_Nm = (EditText) findViewById(R.id.edit_textName);
        edt_Amt = (EditText) findViewById(R.id.edit_TextAmt);
        dbController = new DBController(this);



        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                utang = new Utang(edt_Nm.getText().toString(), edt_Amt.getText().toString());
                addUtang(utang.getName(), utang.getAmt());
            }
        });

        btn_View.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListActivity.class);
                startActivity(intent);
            }
        });
    }

    public void addUtang(String name, String amt){
        boolean inserted = dbController.insert(name, amt);

        if(inserted){
            toastMessage("New utang added");
        }
        else {
            toastMessage("Something went wrong.");
        }
    }

    private void toastMessage(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
